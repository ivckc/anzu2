/*
  ANZU — قاموس الترجمة
  أضف لغة جديدة بإضافة مفتاح جديد هنا (مثلاً "ku" للكردية) وتعبئة نفس الحقول.
  Add a new language by adding a new key here with the same fields.
*/

const ANZU_TRANSLATIONS = {
  ar: {
    dir: "rtl",
    tagline: "مساعدك الشخصي",
    tabLogin: "دخول",
    tabSignup: "حساب جديد",
    nameLabel: "الاسم الكامل",
    namePlaceholder: "الاسم الكامل",
    emailPlaceholder: "البريد الإلكتروني",
    passwordPlaceholder: "كلمة المرور",
    confirmPlaceholder: "تأكيد كلمة المرور",
    submitLogin: "دخول",
    submitSignup: "إنشاء حساب",
    forgot: "نسيت كلمة المرور؟",
    errorRequired: "هذا الحقل مطلوب",
    errorEmail: "أدخل بريد إلكتروني صحيح",
    errorPasswordMatch: "كلمتا المرور غير متطابقتين",
  },
  en: {
    dir: "ltr",
    tagline: "Your personal assistant",
    tabLogin: "Log in",
    tabSignup: "Sign up",
    nameLabel: "Full name",
    namePlaceholder: "Full name",
    emailPlaceholder: "Email address",
    passwordPlaceholder: "Password",
    confirmPlaceholder: "Confirm password",
    submitLogin: "Log in",
    submitSignup: "Create account",
    forgot: "Forgot password?",
    errorRequired: "This field is required",
    errorEmail: "Enter a valid email address",
    errorPasswordMatch: "Passwords do not match",
  },
};
