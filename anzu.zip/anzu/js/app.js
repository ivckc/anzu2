/*
  ANZU — منطق الصفحة
  مقسّم لدوال صغيرة حتى يسهل إضافة صفحات أو خطوات جديدة لاحقاً
  (مثل التحقق بخطوتين، أو تسجيل عبر جهات خارجية).
*/

document.addEventListener("DOMContentLoaded", () => {
  initLanguage();
  initModeTabs();
  initFormValidation();
});

/* ===== اللغة — Language switching ===== */

function initLanguage() {
  const buttons = document.querySelectorAll("[data-lang]");
  const saved = localStorageGet("anzu_lang", "ar");

  applyLanguage(saved);

  buttons.forEach((btn) => {
    btn.addEventListener("click", () => {
      const lang = btn.getAttribute("data-lang");
      applyLanguage(lang);
      localStorageSet("anzu_lang", lang);
    });
  });
}

function applyLanguage(lang) {
  const dict = ANZU_TRANSLATIONS[lang];
  if (!dict) return;

  document.documentElement.setAttribute("lang", lang);
  document.documentElement.setAttribute("dir", dict.dir);

  document.querySelectorAll("[data-i18n]").forEach((el) => {
    const key = el.getAttribute("data-i18n");
    if (dict[key]) el.textContent = dict[key];
  });

  document.querySelectorAll("[data-i18n-placeholder]").forEach((el) => {
    const key = el.getAttribute("data-i18n-placeholder");
    if (dict[key]) el.setAttribute("placeholder", dict[key]);
  });

  document.querySelectorAll("[data-lang]").forEach((btn) => {
    btn.classList.toggle("is-active", btn.getAttribute("data-lang") === lang);
  });
}

/* ===== دخول / حساب جديد — Login/signup tabs ===== */

function initModeTabs() {
  const tabs = document.querySelectorAll("[data-mode-tab]");
  const card = document.querySelector(".anzu-card");
  const submitBtn = document.querySelector("[data-submit-label]");

  tabs.forEach((tab) => {
    tab.addEventListener("click", () => {
      const mode = tab.getAttribute("data-mode-tab");
      card.setAttribute("data-mode", mode);

      tabs.forEach((t) => t.classList.toggle("is-active", t === tab));

      const lang = document.documentElement.getAttribute("lang") || "ar";
      const dict = ANZU_TRANSLATIONS[lang];
      if (submitBtn && dict) {
        submitBtn.textContent = mode === "signup" ? dict.submitSignup : dict.submitLogin;
      }
    });
  });
}

/* ===== التحقق من الحقول — Field validation =====
   نقطة بداية بسيطة؛ اربطها لاحقاً بنداء API حقيقي عند تجهيز النظام الخلفي. */

function initFormValidation() {
  const form = document.querySelector(".anzu-form");
  if (!form) return;

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const mode = document.querySelector(".anzu-card").getAttribute("data-mode");
    let isValid = true;

    form.querySelectorAll(".anzu-field").forEach((field) => {
      const isVisible = field.offsetParent !== null;
      if (!isVisible) return;

      clearFieldError(field);

      if (!field.value.trim()) {
        showFieldError(field, "errorRequired");
        isValid = false;
        return;
      }

      if (field.type === "email" && !isValidEmail(field.value)) {
        showFieldError(field, "errorEmail");
        isValid = false;
      }
    });

    if (mode === "signup") {
      const password = form.querySelector('[name="password"]');
      const confirm = form.querySelector('[name="confirm"]');
      if (password && confirm && password.value !== confirm.value) {
        showFieldError(confirm, "errorPasswordMatch");
        isValid = false;
      }
    }

    if (!isValid) return;

    // هنا تربط نداء API الحقيقي لاحقاً (تسجيل دخول / إنشاء حساب)
    // TODO: connect to your backend/auth endpoint here.
    console.log("ANZU form submitted:", mode);
  });
}

function showFieldError(field, messageKey) {
  field.classList.add("has-error");
  const errorEl = field.parentElement.querySelector(".anzu-field-error");
  if (errorEl) {
    const lang = document.documentElement.getAttribute("lang") || "ar";
    errorEl.textContent = ANZU_TRANSLATIONS[lang][messageKey];
    errorEl.classList.add("is-visible");
  }
}

function clearFieldError(field) {
  field.classList.remove("has-error");
  const errorEl = field.parentElement.querySelector(".anzu-field-error");
  if (errorEl) errorEl.classList.remove("is-visible");
}

function isValidEmail(value) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

/* ===== أدوات مساعدة — Small helpers ===== */

function localStorageGet(key, fallback) {
  try {
    return localStorage.getItem(key) || fallback;
  } catch {
    return fallback;
  }
}

function localStorageSet(key, value) {
  try {
    localStorage.setItem(key, value);
  } catch {
    /* ignore */
  }
}
